package mypack;
public class Car {
  String model;
    int maxSpeed;
    int weight;
  public Car(String model)
  {
    this.model = model;
  }
  public Car(String model,int maxSpeed)
  {
    this.model = model;
    this.maxSpeed = maxSpeed;

  }
  public Car(String model,int maxSpeed, int weight)
  {
    this.model = model;
    this.maxSpeed = maxSpeed;
    this.weight = weight;
  }
  public void show()
  {
    String result = "";
    if (this.model!="")
    {
      result+="model:"+this.model+"\n";
    }
    if (this.maxSpeed!=0)
    {
      result+="maxSpeed:"+this.maxSpeed+"\n";
    }
    if (this.weight!=0)
    {
      result+="weight:"+this.weight+"\n";
    }
    System.out.println(result);
  }
}