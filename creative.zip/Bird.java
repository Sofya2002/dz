public class Bird extends mypack.Animal
{
  public void fly(){
    
  }
  public String getSound(){
    return "chik-chirik";
  }
  
  public boolean canEat(int classification, int isFlyable){
      if (classification<2){
        return true;
      }
      return false;
  }

}