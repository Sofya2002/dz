public class Eagle extends Bird{
  public String getSound(){
    return "AARGGGH";
  } 
  public void fly(){
    //увеличить скорость, включить режим пикирования
  }
  public boolean canEat(int classification, int isFlyable){
    return true;
  }
}