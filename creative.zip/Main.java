import mypack.Animal;
class Main {
  public static void main(String[] args) 
  {
    Animal animal = new Animal();
      System.out.println(animal.getSound());
     Eagle eagle = new Eagle();
    System.out.println(eagle.getSound());
    Bird bird = new Bird();
     System.out.println(bird.getSound());
  }
}