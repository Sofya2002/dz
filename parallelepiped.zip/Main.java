import mypack.Parallelepiped;
class Main {
  public static void main(String[] args) {
    Parallelepiped par =  new Parallelepiped(10, 15, 20);
    System.out.println(par.getB());
    System.out.println(par.volume());
    par.setB(5);
    System.out.println(par.volume());

  }
}