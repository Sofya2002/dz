package mypack;
public class Parallelepiped {
  private int a,b,c;
  public int getA(){
    return this.a;
  }
  public int getB(){
    return this.b;
  }
  public int getC(){
    return this.c;
  }
  public void setA(int tmp){
    this.a = tmp;
  }
  public void setB(int tmp){
    this.b = tmp;
  }
  public void setC(int tmp){
    this.c = tmp;
  }
  public Parallelepiped(int a,int b, int c){
    this.a = a;
    this.b = b;
    this.c = c;
  }
  public int volume(){//объем
    return this.a*this.b*this.c;
  }
  public int square(){
    return 2*(this.a*this.b + this.a*this.c + this.b*this.c);
  }
  
}