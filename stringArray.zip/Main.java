import java.util.*;
class Main {
  public static void main(String[] args) {
    String array[] = {"Masha","Sonya","Chelovek"};
    String name;
    boolean flag = false;//есть ли имя в массиве

    Scanner in = new Scanner(System.in);
    System.out.println("Введите имя:");
    name = in.next();

    for (int i = 0; i<array.length; i++){
      if (name.equals(array[i])){
        flag = true;
      }
    }
    if (flag==true){
      System.out.println(name + " Находится в массиве");
    }
    else{
      System.out.println(name + " В массиве нет");
    }
  }
}